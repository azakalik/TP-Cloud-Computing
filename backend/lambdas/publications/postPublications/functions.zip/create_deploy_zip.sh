#!/bin/bash

# Create a zip file named functions.zip containing the contents of the current directory
zip -r functions.zip .